import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.print("Enter Your Number : ");
        Scanner s1 = new Scanner(System.in);
        int number = s1.nextInt();
        if(number%2==0){
            System.out.println("The Number You Enter ( " + number + " )  -> Even Number ");
        }
        else {
            System.out.println("The Number You Enter " + number + " -> Odd Number ");
        }
    }
}