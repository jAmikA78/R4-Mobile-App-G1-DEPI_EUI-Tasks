import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.print("Enter Your IP Address : ");
        boolean flag = false;
        Scanner s1 = new Scanner(System.in);
        String IP = s1.nextLine();
        String[] numbers = IP.split("\\.");
        if(numbers.length==4){
            for(String s : numbers) {
                int num = Integer.parseInt(s);
                if (num > 0 && num < 256) {
                    continue;
                }
                else {
                    flag=true;
                    break;
                }
            }
            if(flag){
                System.out.println("========= IP Address not Valid =========");
            }
            else {
                System.out.println("========= IP Address Valid =========");
                for(String s : numbers){
                    int num = Integer.parseInt(s);
                    System.out.println(num);
                }
            }
        }
        else {
            System.out.println("IP Address not Valid");
        }
    }
}