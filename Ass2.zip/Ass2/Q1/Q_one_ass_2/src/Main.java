//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Student std1 = new Student();
        std1.setName("Mohamed");
        std1.setAge(20);
        std1.setTrack("Computer and Systems Department");
        std1.setNationality("Egyptian");
        std1.setGPA(3.3);
        std1.print();
    }
}