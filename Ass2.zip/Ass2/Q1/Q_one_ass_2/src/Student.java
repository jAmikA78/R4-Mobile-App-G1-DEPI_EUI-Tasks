public class Student {
    private String name;
    private int age ;
    private String track ;
    private String Nationality ;
    private double GPA ;
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public void setTrack(String track) {
        this.track = track;
    }
    public void setNationality(String nationality) {
        Nationality = nationality;
    }
    public void setGPA(double GPA) {
        this.GPA = GPA;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public String getTrack() {
        return track;
    }

    public String getNationality() {
        return Nationality;
    }
    public double getGPA() {
        return GPA;
    }
    public void print (){
        System.out.println("Name : " + name +"\n"
                + "Age : " + age +"\n"
                + "Nationality : " + Nationality +"\n"
                + "Track : " + track +"\n"
                + "GPA : " + GPA +"\n");
    }
}
