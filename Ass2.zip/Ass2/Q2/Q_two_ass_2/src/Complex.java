public class Complex {
    private int real ;
    private int img ;

    public Complex(){
    }
    public Complex(int real , int img){
        this.real=real;
        this.img=img;
    }
    public void setReal(int real) {
        this.real = real;
    }
    public void setImg(int img) {
        this.img = img;
    }
    public int getReal() {
        return real;
    }
    public int getImg() {
        return img;
    }
    public static Complex add(Complex c1, Complex c2){
        Complex result1 = new Complex(c1.real+c2.real,c1.img+c2.img);
        return result1;
    }
    public static Complex sub(Complex c1, Complex c2){
        Complex result2 = new Complex(c1.real-c2.real,c1.img-c2.img);
        return result2;
    }
    public void print(Complex c1){
        if(c1.img>=0){
            System.out.println(c1.real + " + " + c1.img  +" i"  );
        }else {
            System.out.println(c1.real + " - " + (-1 * c1.img) + " i");
        }
    }
}
