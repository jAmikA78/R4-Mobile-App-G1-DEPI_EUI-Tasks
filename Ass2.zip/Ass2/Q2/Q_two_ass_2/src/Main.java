//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Complex com = new Complex(5,-8);
        Complex com2 = new Complex(10,15);
        Complex result = Complex.add(com,com2);
        Complex result1 = Complex.sub(com,com2);

        Complex ans =new Complex();
        ans.print(result);
        ans.print(result1);
    }
}