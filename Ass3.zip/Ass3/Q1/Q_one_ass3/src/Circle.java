public class Circle extends Shape{
    public Circle(int dim){
        super(dim);
    }
    @Override
    public double calculateArea(){
        return 3.14*getDim()*getDim();
    }
}
