public class Main {
    public static void main(String[] args) {
        Rectangle R1 = new Rectangle(5,4);
        System.out.println("Area For Rectangle : " + R1.calculateArea());
        Circle C1 = new Circle(5);
        System.out.println("Area For Circle : " + C1.calculateArea());
        Triangle T1 = new Triangle(5,4);
        System.out.println("Area For Triangle : " + T1.calculateArea());
        Picture p1 = new Picture();
        System.out.println("Total Sum Area For Three Shape : "+ p1.sumAreas(R1,C1,T1));
    }
}