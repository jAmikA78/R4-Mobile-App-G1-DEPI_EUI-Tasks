public class Picture {
    public double sumAreas( Rectangle R1 , Circle C1 , Triangle T1 ){
        return R1.calculateArea()+ C1.calculateArea()+ T1.calculateArea();
    }
}
