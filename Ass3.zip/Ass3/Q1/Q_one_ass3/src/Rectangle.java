public class Rectangle extends Shape {
    private int width ;
    public Rectangle(int dim , int width){
        super(dim);
        this.width=width;
    }
    @Override
    public double calculateArea(){
        return width* getDim();
    }
}
