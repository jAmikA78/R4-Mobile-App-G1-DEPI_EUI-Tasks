public abstract class Shape {
    private int dim ;
    public Shape(int dim){
        this.dim=dim;
    }
    public void setDim(int dim) {
        this.dim = dim;
    }
    public int getDim() {
        return dim;
    }

    public abstract double calculateArea();
}
