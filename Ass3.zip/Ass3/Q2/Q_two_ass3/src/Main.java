public class Main {
    public static void main(String[] args) {
        Parent P = new Parent(5,3);
        System.out.println(P.sum());
        Child ch = new Child(P.getNum1(),P.getNum2(),4);
        System.out.println(ch.sum());
    }
}