import javax.swing.*;
import java.awt.*;

public class LampDrawing extends JPanel {


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

//        g2.setColor(Color.WHITE);
//        g2.fillRoundRect(150, 80, 300, 250, 120, 120);
//        g2.setColor(Color.BLACK);
//        g2.drawRoundRect(150, 80, 300, 250, 120, 120);

        g2.setColor(Color.YELLOW);
        g2.fillOval(180, 60, 240, 60);
        g2.setColor(Color.BLACK);
        g2.drawOval(180, 60, 240, 60);

        g2.drawLine(180,90,100,290);
        g2.drawLine(420,90,500,290);

        g2.drawArc(110,30,380,300,0,-180);
        g2.setColor(Color.YELLOW);
        g2.fillOval(245, 150, 110, 150);
        g2.setColor(Color.BLACK);
        g2.drawOval(245, 150, 110, 150);

        g2.setColor(Color.YELLOW);
        g2.fillOval(160, 170, 60, 90);
        g2.setColor(Color.BLACK);
        g2.drawOval(160, 170, 60, 90);

        g2.setColor(Color.YELLOW);
        g2.fillOval(380, 170, 60, 90);
        g2.setColor(Color.BLACK);
        g2.drawOval(380, 170, 60, 90);

        g2.drawLine(290, 330, 260, 400);
        g2.drawLine(310, 330, 340, 400);

        g2.drawRect(220, 400, 160, 20);
    }
}