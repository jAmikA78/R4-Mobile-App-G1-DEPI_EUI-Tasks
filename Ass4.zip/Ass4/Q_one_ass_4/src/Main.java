import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("LampDrawing");
         frame.setSize(600,500);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.add(new LampDrawing());
         frame.setVisible(true);
    }
}