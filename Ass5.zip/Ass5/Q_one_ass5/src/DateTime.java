import javax.swing.*;
import java.awt.*;
import java.util.Date;

public class DateTime extends JFrame implements Runnable {
    Thread thread ;
    public DateTime(){
        this.setTitle("Date & Time");
        this.setSize(400, 300);
        this.setLocation(500,200);
        thread = new Thread(this);
        thread.start();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    @Override
    public void run(){
        while (true){
            repaint();
            try {
                thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public void paint(Graphics g){
        super.paint(g);
        Date d = new Date();
        g.drawString(d.toString(),100,150);
    }
}
