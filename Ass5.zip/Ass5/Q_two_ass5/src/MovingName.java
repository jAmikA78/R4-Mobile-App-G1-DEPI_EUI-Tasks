import javax.swing.*;
import java.awt.*;

public class MovingName extends JFrame implements Runnable {
    Thread thread;
    String name ="Mohamed Mamdouh " ;
    int x = 5 , y = 420 ,textSize = 20 ;
    public MovingName() {
        this.setTitle("Moving Name ");
        this.setSize(600, 450);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        while (true) {
            if(x<getWidth()-textSize){
                x+=10;
            }else {
                x=-160;
            }
            repaint();
            try {
                Thread.sleep(100);

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString(name,x,y);
    }
}

