import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Counter extends JFrame implements ActionListener {
    int value = 0 ;
    JButton Btn_add;
    JButton Btn_sub;
    JLabel cont;
    public Counter(){
        this.setSize(600,500);
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Btn_add = new JButton(" +++ ");
        Btn_sub = new JButton(" --- ");
        cont = new JLabel("Counter value is : "+value);
        Btn_add.setBounds(170,80,90,30);
        Btn_sub.setBounds(330,80,90,30);
        cont.setBounds(150,250,200,100);
        cont.setFont(new Font("Arial",Font.BOLD,20));
        this.add(Btn_add);
        this.add(Btn_sub);
        this.add(cont);
        Btn_add.addActionListener(this);
        Btn_sub.addActionListener(this);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==Btn_add){
            value++;
        }
        else{
            value--;
        }
        cont.setText("Counter value is : "+value);
    }
}
