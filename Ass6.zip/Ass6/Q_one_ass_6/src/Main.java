public class Main {
    public static void main(String[] args) {
        Counter c1 = new Counter();
    }
}