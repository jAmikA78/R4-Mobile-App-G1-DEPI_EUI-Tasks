import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Draw extends JFrame implements MouseMotionListener {
int x1,y1,x2,y2;
    public Draw(){
        this.setSize(600,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addMouseMotionListener(this);
        this.setVisible(true);

    }
    @Override
    public void mouseDragged(MouseEvent e) {
        y2=e.getY();
        x2=e.getX();
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        y1=e.getY();
        x1=e.getX();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.RED);
        g.setFont(new Font("Arial",Font.BOLD,30));
        g.drawLine(x1,y1,x2,y2);
    }
}
