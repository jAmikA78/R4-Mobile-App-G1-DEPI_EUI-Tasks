public class Main {
    public static void main(String[] args) {
        Draw D = new Draw();
    }
}