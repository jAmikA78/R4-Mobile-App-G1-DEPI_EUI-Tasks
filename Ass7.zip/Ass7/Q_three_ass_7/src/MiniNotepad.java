import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MiniNotepad extends JFrame {
    static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MiniNotepad.class.getName());
    JTextArea textArea;
    JButton btnSave, btnOpen;

    public MiniNotepad() {
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        btnSave = new JButton("Save");
        btnSave.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showSaveDialog(MiniNotepad.this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (FileWriter fw = new FileWriter(file)) {
                    fw.write(textArea.getText());
                    textArea.setText("");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        btnOpen = new JButton("Open");
        btnOpen.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showOpenDialog(MiniNotepad.this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try (FileReader fr = new FileReader(file)) {
                    textArea.read(fr, null);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        JPanel southPanel = new JPanel();
        southPanel.add(btnSave);
        southPanel.add(btnOpen);
        add(southPanel, BorderLayout.SOUTH);
        setVisible(true);
    }
}
