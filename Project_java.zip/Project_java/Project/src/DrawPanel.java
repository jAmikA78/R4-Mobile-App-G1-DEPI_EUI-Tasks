import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

public class DrawPanel extends JPanel implements MouseMotionListener, MouseListener {
    Color currentColor = Color.BLACK;
    public boolean solid = true;
    ArrayList<ColoredShape> shapes = new ArrayList<ColoredShape>();
    int startX, startY, endX, endY;
    boolean dragging = false;
    String[] tools = {"LINE", "RECT", "OVAL", "PENCIL", "ERASER"};
    String currentTool = "PENCIL";

    class ColoredShape {
        Shape shape;
        Color color;
        boolean solid;
        public ColoredShape(Shape s, Color c, boolean solid){
            this.shape = s;
            this.color = c;
            this.solid = solid;
        }
    }

    public DrawPanel(){
        setBackground(Color.WHITE);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    public void clearAll() {
        shapes.clear();
        repaint();
    }
    public void undoFun(){
        if (!shapes.isEmpty()) {
            shapes.remove(shapes.size() - 1);
            repaint();
        }
    }
    public void setCurrentColor(Color c) {
        currentColor = c;
    }
    public void setSolid(boolean current){
        solid=current;
    }
    public void setTool(String currentTool){
        this.currentTool=currentTool;
    }
    public void addShape(Shape s){
        shapes.add(new ColoredShape(s, currentColor, solid));
        repaint();
    }
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        for (ColoredShape cs : shapes) {
            g2.setColor(cs.color);
            if (cs.solid) {
                g2.setStroke(new BasicStroke(2));
            } else {
                float[] dash = {10.0f};
                g2.setStroke(new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f));
            }
            g2.draw(cs.shape);
        }
        if(dragging){
            g2.setColor(currentColor);
            if(solid){
                g2.setStroke(new BasicStroke(2));
            } else {
                float[] dash = {10.0f};
                g2.setStroke(new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash, 0.0f));
            }

            int x = Math.min(startX, endX);
            int y = Math.min(startY, endY);
            int w = Math.abs(startX - endX);
            int h = Math.abs(startY - endY);

            switch(currentTool){
                case "RECT":
                    g2.drawRect(x, y, w, h);
                    break;
                case "OVAL":
                    g2.drawOval(x, y, w, h);
                    break;
                case "LINE":
                    g2.drawLine(startX, startY, endX, endY);
                    break;
                case "PENCIL":
                    g2.drawLine(startX, startY, endX, endY);
                    startX = endX;
                    startY = endY;
                    break;
                case "ERASER":
                    g2.setColor(Color.WHITE);
                    g2.setStroke(new BasicStroke(40));
                    g2.drawLine(startX, startY, endX, endY);
                    int dx = endX - startX;
                    int dy = endY - startY;
                    int steps = Math.max(Math.abs(dx), Math.abs(dy));
                    for(int i=0;i<steps;i++){
                        int px = startX + i*dx/steps;
                        int py = startY + i*dy/steps;
                        g2.fillOval(px-30, py-30, 60, 60);
                    }

                    startX = endX;
                    startY = endY;
                    break;
            }
            }
    }
    @Override
    public void mouseClicked(MouseEvent e) {
    }
    @Override
    public void mousePressed(MouseEvent e) {
        startX = e.getX();
        startY = e.getY();
        dragging = true;
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        endX = e.getX();
        endY = e.getY();
        dragging = false;
        int x = Math.min(startX, endX);
        int y = Math.min(startY, endY);
        int w = Math.abs(startX - endX);
        int h = Math.abs(startY - endY);

        switch(currentTool){
            case "RECT":
                addShape(new Rectangle(x, y, w, h));
                break;
            case "OVAL":
                addShape(new java.awt.geom.Ellipse2D.Float(x, y, w, h));
                break;
            case "LINE":
                addShape(new java.awt.geom.Line2D.Float(startX, startY, endX, endY));
                break;
        }
    }
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    @Override
    public void mouseExited(MouseEvent e) {
    }
    @Override
    public void mouseDragged(MouseEvent e) {
        endX = e.getX();
        endY = e.getY();
        if(currentTool.equals("PENCIL")) {
            addShape(new java.awt.geom.Line2D.Float(startX, startY, endX, endY));
            startX = endX;
            startY = endY;
        } else if(currentTool.equals("ERASER")) {
            int size = 40;
            ColoredShape cs = new ColoredShape(
                    new java.awt.geom.Ellipse2D.Float(endX - size/2, endY - size/2, size, size),
                    Color.WHITE,
                    true
            );
            shapes.add(cs);
            startX = endX;
            startY = endY;

        }
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
