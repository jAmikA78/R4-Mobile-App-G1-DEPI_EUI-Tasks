import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener,ItemListener {
    private boolean flag = true;
    JLabel fun , mode , color ;
    JButton clear , undo , line , rect , oval , pen
            ,eraser , btn_black , btn_green , btn_red , btn_blue ;
    JCheckBox solid ,dotted ;
    DrawPanel panel;

    public Project(){
        this.setTitle(" Paint Brush ");
        this.setSize(1600,850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);

        panel = new DrawPanel();
        panel.setBounds(20,80,1490,690);
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        fun = new JLabel("Functions : ");
        fun.setBounds(10,20,90,40);
        fun.setFont(new Font("Arial",Font.BOLD,15));

        clear = new JButton("Clear ");
        clear.setBounds(110,25,80,30);
        clear.setFont(new Font("Arial",Font.BOLD,15));

        undo = new JButton("Undo ");
        undo.setBounds(200,25,80,30);
        undo.setFont(new Font("Arial",Font.BOLD,15));

        mode = new JLabel("Paint Mode : ");
        mode.setBounds(295,20,100,40);
        mode.setFont(new Font("Arial",Font.BOLD,15));

        line = new JButton("Line ");
        line.setBounds(405,25,80,30);
        line.setFont(new Font("Arial",Font.BOLD,15));

        rect = new JButton("Rectangle ");
        rect.setBounds(500,25,120,30);
        rect.setFont(new Font("Arial",Font.BOLD,15));

        oval = new JButton("Oval ");
        oval.setBounds(635,25,80,30);
        oval.setFont(new Font("Arial",Font.BOLD,15));

        pen = new JButton("Pencil ");
        pen.setBounds(730,25,85,30);
        pen.setFont(new Font("Arial",Font.BOLD,15));

        eraser = new JButton("Eraser ");
        eraser.setBounds(830,25,90,30);
        eraser.setFont(new Font("Arial",Font.BOLD,15));

        solid = new JCheckBox("Solid ");
        solid.setBounds(930,25,70,30);
        solid.setFont(new Font("Arial",Font.BOLD,15));

        dotted = new JCheckBox("Dotted ");
        dotted.setBounds(1000,25,80,30);
        dotted.setFont(new Font("Arial",Font.BOLD,15));

        color = new JLabel("Color : ");
        color.setBounds(1085,20,70,40);
        color.setFont(new Font("Arial",Font.BOLD,15));

        btn_black = new JButton("Black ");
        btn_black.setBounds(1155,25,80,30);
        btn_black.setBackground(Color.black);
        btn_black.setFont(new Font("Arial",Font.BOLD,15));

        btn_red = new JButton("Red ");
        btn_red.setBounds(1250,25,70,30);
        btn_red.setBackground(Color.red);
        btn_red.setFont(new Font("Arial",Font.BOLD,15));

        btn_green = new JButton("Green ");
        btn_green.setBounds(1335,25,85,30);
        btn_green.setBackground(Color.green);
        btn_green.setFont(new Font("Arial",Font.BOLD,15));

        btn_blue = new JButton("Blue ");
        btn_blue.setBounds(1435,25,80,30);
        btn_blue.setBackground(Color.blue);
        btn_blue.setFont(new Font("Arial",Font.BOLD,15));

        this.add(panel);
        this.add(fun);
        this.add(clear);
        this.add(undo);
        this.add(mode);
        this.add(line);
        this.add(rect);
        this.add(oval);
        this.add(pen);
        this.add(eraser);
        this.add(solid);
        this.add(dotted);
        this.add(color);
        this.add(btn_black);
        this.add(btn_green);
        this.add(btn_red);
        this.add(btn_blue);

        clear.addActionListener(this);
        undo.addActionListener(this);
        btn_green.addActionListener(this);
        btn_blue.addActionListener(this);
        btn_black.addActionListener(this);
        btn_red.addActionListener(this);
        solid.addItemListener(this);
        dotted.addItemListener(this);
        rect.addActionListener(this);
        line.addActionListener(this);
        oval.addActionListener(this);
        pen.addActionListener(this);
        eraser.addActionListener(this);
        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==clear){
            panel.clearAll();
        }
        if(e.getSource()==undo){
            panel.undoFun();
        }
        if(e.getSource()==btn_black){
            panel.setCurrentColor(Color.BLACK);
        }
        if(e.getSource()==btn_blue){
            panel.setCurrentColor(Color.BLUE);
        }
        if(e.getSource()==btn_green){
            panel.setCurrentColor(Color.GREEN);
        }
        if(e.getSource()==btn_red){
            panel.setCurrentColor(Color.RED);
        }
        if(e.getSource()==rect){
            panel.setTool("RECT");
        }
        else if(e.getSource()==line){
            panel.setTool("LINE");
        }
        else if(e.getSource()==oval){
            panel.setTool("OVAL");
        }
        else if(e.getSource()==pen){
            panel.setTool("PENCIL");
        }
        if(e.getSource()==eraser){
            panel.setTool("ERASER");
        }
    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        Object source = e.getSource();

        if (source == solid) {
            if (solid.isSelected()) {
                panel.setSolid(true);
                dotted.setSelected(false);
            }
        } else if (source == dotted) {
            if (dotted.isSelected()) {
                panel.setSolid(false);
                solid.setSelected(false);
            }
        }
    }
}
